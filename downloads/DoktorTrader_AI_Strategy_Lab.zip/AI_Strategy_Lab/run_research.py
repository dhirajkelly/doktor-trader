#!/usr/bin/env python3
"""XAU Lab — full research cycle:  research → develop → test → evaluate → improve → revalidate.

  python run_research.py                      # pakai config.toml
  python run_research.py --generations 4      # cepat, untuk coba-coba
  python run_research.py --llm                # aktifkan agen Claude (butuh ANTHROPIC_API_KEY)
  python run_research.py --no-holdout         # jangan buka holdout walau ada yang lolos
"""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

from xaulab import report, search, validation
from xaulab.lab import Lab, load_config


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config.toml")
    ap.add_argument("--generations", type=int)
    ap.add_argument("--population", type=int)
    ap.add_argument("--llm", action="store_true", help="aktifkan agen Claude")
    ap.add_argument("--no-holdout", action="store_true")
    ap.add_argument("--out", default="output")
    a = ap.parse_args()

    cfg = load_config(a.config)
    if a.generations:
        cfg["search"]["generations"] = a.generations
    if a.population:
        cfg["search"]["population"] = a.population
    if a.llm:
        cfg["search"]["use_llm_agent"] = True
    out = Path(a.out)
    out.mkdir(exist_ok=True)

    t0 = time.time()
    print("== Memuat data ==")
    lab = Lab(cfg)
    for tf, b in lab.full.items():
        print(f"  {tf}: {len(b):,} bar  {b.index[0].date()} → {b.index[-1].date()}")

    print("\n== Loop self-improvement (data riset saja) ==")
    ledger, history = search.run(lab, cfg)
    ledger.save(out / "trial_ledger.csv")

    print("\n== Revalidasi (G1–G5) ==")
    val = validation.validate_finalists(lab, ledger, cfg)

    print("\n== Holdout (G6) ==")
    if a.no_holdout:
        hold = {"opened": False, "reason": "dilewati (--no-holdout)"}
        print("  dilewati")
    else:
        hold = validation.open_holdout(lab, val, cfg, out)

    print("\n== Laporan ==")
    res = report.build(out, cfg, lab, ledger, history, val, hold)
    if getattr(ledger, "agent_log", None):
        (out / "agent_log.json").write_text(json.dumps(ledger.agent_log, indent=1))
    print(f"  {out / 'report.html'}\n  {out / 'results.json'}\n  {out / 'trial_ledger.csv'}")
    print(f"\nSelesai dalam {time.time() - t0:.0f} detik. Disetujui untuk paper trading: {res['approved'] or 'tidak ada'}")


if __name__ == "__main__":
    main()
