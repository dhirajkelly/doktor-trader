# AI Strategy Lab (XAUUSD) — Doktor Trader

Laboratorium riset strategi emas yang **memperbaiki dirinya sendiri**, tapi dengan rem anti-overfitting.

```
Riset → Bangun → Uji → Nilai → Perbaiki → Validasi ulang
  ↑                                            │
  └──────── hanya data 2017–2023 ──────────────┘   →  6 gate  →  holdout terkunci  →  paper trading
```

> Edukasi saja. Hasil backtest itu hipotetis, bukan jaminan dan bukan sinyal. Uji di akun demo dulu.

## Isi

| File | Fungsi |
|---|---|
| `run_research.py` | Menjalankan satu siklus penuh: loop riset, gate validasi, holdout, laporan |
| `live_signal.py` | Paper trading: status setup terkini + entry, SL, TP, **lot** dan **RR** (tidak pernah order sendiri) |
| `fetch_mt5_m1.py` | Ekspor data M1 XAUUSD dari terminal MT5 (Windows) |
| `config.toml` | Semua pengaturan: periode, biaya, risiko, parameter pencarian, ambang gate |
| `xaulab/engine.py` | Engine backtest (numba): bid/ask, slippage, swap, SL/TP intrabar, gap |
| `xaulab/strategies.py` | 4 keluarga strategi + ruang parameternya |
| `xaulab/search.py` | Loop evolusioner + ledger semua percobaan |
| `xaulab/agent_llm.py` | Agen Claude opsional yang mengusulkan hipotesis baru |
| `xaulab/validation.py` | Gate G1–G6 |
| `xaulab/metrics.py` | Sharpe, DSR, PBO (CSCV), Monte Carlo |
| `tests/test_core.py` | Tes harga eksekusi, gap, lot size, dan **tes anti look-ahead** |

## Cara pakai

```bash
pip install -r requirements.txt
python fetch_mt5_m1.py --symbol XAUUSD          # Windows + MT5 login. Atau taruh CSV export MT5 lalu ubah m1_path
python tests/test_core.py                        # semua harus "ok"
python run_research.py                           # ±4 menit untuk 25 generasi × 150
python run_research.py --llm                     # + agen Claude (set ANTHROPIC_API_KEY dulu)
python live_signal.py --data data/xauusd_m1.parquet --equity 1000 --risk 1
```

Hasil ada di `output/`: `report.html` (laporan), `results.json` (dipakai halaman AI Strategy Lab di dhirajkelly.id), `trial_ledger.csv` (semua percobaan).

## Keluarga strategi

1. **ema_trend**: persilangan EMA cepat/lambat, filter ADX opsional
2. **donchian**: breakout channel N bar, filter tren EMA opsional
3. **rsi_revert**: RSI ekstrem searah tren (beli koreksi di uptrend)
4. **session_break**: breakout range sesi Asia saat London/NY

Semua memakai SL berbasis ATR (atau lebar range), TP = RR × SL, time stop, filter arah dan sesi. Pencarian maupun agen AI **hanya boleh memilih titik di dalam ruang parameter ini**, tidak menulis kode bebas. Karena itu setiap percobaan tercatat dan bisa diulang.

## Kenapa hasilnya bisa "tidak ada yang lolos"

Itu hasil yang jujur, bukan bug. Mesin yang mencoba ribuan variasi **pasti** menemukan sesuatu yang tampak bagus di masa lalu. Gate-nya yang memisahkan keberuntungan dari edge:

| Gate | Pertanyaan |
|---|---|
| G1 Out-of-sample | Masih untung di 2024–pertengahan 2025 yang tidak dipakai saat riset? |
| G2 Deflated Sharpe | Sharpe-nya lebih tinggi dari Sharpe terbaik yang *diharapkan dari kebetulan* setelah mencoba N ide? (N dihitung dari kelompok ide yang benar-benar berbeda) |
| G3 PBO | Seberapa sering strategi terbaik di separuh data jadi di bawah median di separuh lainnya? |
| G4 Stress biaya | Masih positif jika spread ×1,5 dan slippage ×2? |
| G5 Stabilitas | Parameter tetangga (±10%) juga untung? |
| G6 Holdout | Data terbaru (Juli 2025 → sekarang) dibuka **sekali**, hanya untuk yang lolos G1–G5. Setiap pembukaan dicatat di `output/holdout_log.json` |

## Asumsi biaya (ubah di `config.toml` sesuai broker kamu)

* Spread: dari data MT5 (rata-rata spread per menit dalam bar), minimal 200 point = $0,20/oz
* Slippage: 50 point = $0,05/oz per sisi (SL & market order; TP dianggap limit)
* Swap: long −40, short −10 USD/lot/malam, triple hari Rabu. **Ini asumsi**, cek spesifikasi kontrak broker
* Lot: 1 lot = 100 oz, jadi gerak $1 = $100 per lot. Lot dibulatkan ke bawah, tidak pernah ke atas

## Agen AI

`--llm` menyalakan agen (default model `claude-fable-5-2`, ganti di config). Agen hanya membaca leaderboard **data riset**, mengusulkan parameter + hipotesis dalam JSON, lalu usulannya divalidasi dan dihitung sebagai percobaan. Artinya makin banyak ide AI, makin tinggi ambang DSR yang harus dilewati. AI tidak bisa "mengakali" holdout karena ia tidak pernah melihatnya.

## Batasan

* Backtest bar (M15/H1/H4): urutan harga di dalam bar tidak diketahui; bila SL dan TP kena di bar yang sama dianggap SL.
* Data satu broker; spread/swap broker lain berbeda.
* Lolos semua gate ≠ pasti untung. Langkah berikutnya tetap paper trading minimal 2–3 bulan dengan lot yang dihitung `live_signal.py`.
