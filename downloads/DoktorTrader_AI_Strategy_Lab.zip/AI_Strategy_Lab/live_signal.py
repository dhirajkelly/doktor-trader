#!/usr/bin/env python3
"""Paper-trading helper: shows the CURRENT state of each strategy from results.json on the
latest data, with entry/SL/TP, exact lot size and RR. It never places orders.

  python live_signal.py --data XAUUSD_M1_export.csv            # MT5 export (M1 or the strategy timeframe)
  python live_signal.py --data data/xauusd_m1.parquet --equity 5000 --risk 0.5

Only strategies with approved_for_paper = true are shown, unless --show-all (for study only).
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from xaulab import data as D
from xaulab.lab import load_config
from xaulab.sizing import setup_card
from xaulab.strategies import GENERATORS, Cache


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--results", default="output/results.json")
    ap.add_argument("--config", default="config.toml")
    ap.add_argument("--equity", type=float)
    ap.add_argument("--risk", type=float, help="risk per trade in %, e.g. 1 = 1%%")
    ap.add_argument("--show-all", action="store_true")
    a = ap.parse_args()

    cfg = load_config(a.config)
    rc, cc = cfg["risk"], cfg["costs"]
    equity = a.equity or rc["account_equity"]
    risk = (a.risk / 100) if a.risk else rc["risk_per_trade"]
    res = json.loads(Path(a.results).read_text())
    strategies = [f for f in res["finalists"] if a.show_all or f.get("approved_for_paper")]
    if not strategies:
        print("Belum ada strategi yang disetujui untuk paper trading (semua gate harus lolos).")
        print("Pakai --show-all hanya untuk belajar; strategi tersebut BELUM terbukti.")
        return

    m1 = D.load_m1(a.data)
    print(f"Data terakhir: {m1.index[-1]}  close {m1['close'].iloc[-1]:.2f}\n")
    for f in strategies:
        p = f["params"]
        df = D.resample(m1, p["tf"]).iloc[:-1]  # drop the still-forming bar
        bars = D.to_bars(df, p["tf"], cfg["data"]["point"], cc["spread_floor_points"], cc["spread_mult"])
        sig, sl = GENERATORS[p["family"]](Cache(bars), p)
        last = len(bars) - 1
        recent = np.flatnonzero(sig[-50:])
        tag = "" if f.get("approved_for_paper") else "   [BELUM LOLOS GATE — studi saja]"
        print(f"■ {f['desc']}{tag}")
        if sig[last] == 0:
            ago = f"{50 - recent[-1] - 1} bar lalu" if len(recent) else "tidak ada dalam 50 bar"
            print(f"  Tidak ada setup baru di bar terakhir ({bars.index[last]}). Sinyal terakhir: {ago}.\n")
            continue
        side = "BUY" if sig[last] > 0 else "SELL"
        px = bars.close[last]
        d = float(sl[last])
        spread = bars.spread_px[last]
        entry = px + spread if side == "BUY" else px
        stop = entry - d if side == "BUY" else entry + d
        tp = entry + p["rr"] * d if side == "BUY" else entry - p["rr"] * d
        card = setup_card(equity, risk, d, p["rr"], contract=rc["contract_size"], min_lot=rc["min_lot"], step=rc["lot_step"])
        print(f"  Setup {side} (paper trade) di open bar berikutnya, perkiraan entry {entry:.2f}")
        print(f"  SL {stop:.2f} (${d:.2f}/oz)  ·  TP {tp:.2f}  ·  RR 1:{p['rr']:g}")
        print(f"  Lot {card['lot']:.2f} untuk ekuitas ${equity:,.0f} risk {risk:.1%} "
              f"(risiko aktual ${card['actual_risk_usd']:.0f}, potensi ${card['potential_reward_usd']:.0f}) {card['note']}")
        print(f"  Time stop: tutup setelah {p['max_hold']} bar {p['tf']} jika SL/TP belum kena.\n")


if __name__ == "__main__":
    main()
