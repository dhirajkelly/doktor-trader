"""Core correctness tests:  python -m pytest -q tests   (or: python tests/test_core.py)"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from xaulab import data as D  # noqa: E402
from xaulab import metrics as MX  # noqa: E402
from xaulab.engine import CostModel, backtest  # noqa: E402
from xaulab.sizing import lot_size  # noqa: E402


def make_bars(o, h, l, c, spread=0.2, start="2024-01-01 10:00"):
    idx = pd.date_range(start, periods=len(c), freq="1h", tz="UTC")
    df = pd.DataFrame({"open": o, "high": h, "low": l, "close": c, "tick_volume": 1, "spread": spread / 0.001}, index=idx)
    return D.to_bars(df, "H1", 0.001, 0, 1.0)


NOCOST = CostModel(slip_px=0.0, comm_px=0.0, swap_long_px=0.0, swap_short_px=0.0, triple_wd=2)


def test_long_tp_and_prices():
    # signal on bar 0 -> enter bar 1 open (100) at ask 100.2; SL dist 2 -> SL 98.2, TP (rr 2) 104.2
    o = [100, 100, 101, 103, 104]
    h = [100, 101, 103, 105, 105]
    l = [99, 99.5, 100, 102, 103]
    c = [100, 101, 103, 104, 104]
    b = make_bars(o, h, l, c)
    sig = np.array([1, 0, 0, 0, 0])
    sl = np.full(5, 2.0)
    t = backtest(b, sig, sl, 2.0, 100, NOCOST)
    assert len(t) == 1
    r = t.iloc[0]
    assert r.entry_i == 1 and r.exit_i == 3 and r.reason == 1
    assert abs(r.pnl_px - 4.0) < 1e-9 and abs(r.R - 2.0) < 1e-9


def test_same_bar_sl_and_tp_assumes_sl():
    o = [100, 100, 100]
    h = [100, 110, 100]
    l = [100, 90, 100]
    c = [100, 100, 100]
    b = make_bars(o, h, l, c, spread=0.0)
    t = backtest(b, np.array([1, 0, 0]), np.full(3, 2.0), 2.0, 100, NOCOST)
    assert t.iloc[0].reason == 0 and abs(t.iloc[0].R + 1.0) < 1e-9


def test_short_pays_spread_on_exit():
    # short entry at bid 100; SL hit when ASK (bid+0.5) >= 102 -> bid high 101.6 triggers
    o = [100, 100, 100.5]
    h = [100, 100.5, 101.6]
    l = [100, 99.8, 100.4]
    c = [100, 100.2, 101]
    b = make_bars(o, h, l, c, spread=0.5)
    t = backtest(b, np.array([-1, 0, 0]), np.full(3, 2.0), 3.0, 100, NOCOST)
    assert t.iloc[0].reason == 0 and t.iloc[0].exit_i == 2


def test_gap_through_stop_fills_at_open():
    o = [100, 100, 95]
    h = [100, 100.5, 96]
    l = [100, 99.5, 94]
    c = [100, 100, 95]
    b = make_bars(o, h, l, c, spread=0.0)
    t = backtest(b, np.array([1, 0, 0]), np.full(3, 2.0), 2.0, 100, NOCOST)
    assert abs(t.iloc[0].pnl_px - (95 - 100)) < 1e-9  # worse than the -2 stop


def test_lot_size_xau():
    # $10k, 1% = $100; SL $5/oz -> 100 / (5*100) = 0.2 lot
    r = lot_size(10_000, 0.01, 5.0)
    assert r["lot"] == 0.2 and r["actual_risk_usd"] == 100.0
    assert lot_size(500, 0.01, 10.0)["lot"] == 0.0  # too small an account -> refuse, not round up


def test_dsr_penalises_many_trials():
    rng = np.random.default_rng(0)
    r = rng.normal(0.0004, 0.01, 1500)
    one = MX.deflated_sharpe(r, 1, 0.0)["dsr"]
    many = MX.deflated_sharpe(r, 2000, 0.0006)["dsr"]
    assert many < one


def test_no_lookahead_research_window():
    """Changing data AFTER research_end must not change any research-window result."""
    from xaulab.lab import Lab, load_config
    root = Path(__file__).resolve().parents[1]
    cfg = load_config(root / "config.toml")
    if not (root / "data" / "xauusd_H1.parquet").exists():
        return
    lab = Lab(cfg, root)
    p = {"family": "donchian", "tf": "H1", "n": 40, "trend_ema": 200, "atr_sl": 2.0, "rr": 2.0,
         "max_hold": 60, "direction": "both", "session": "all"}
    a, *_ = lab.evaluate(p, "research")
    b = lab.full["H1"]
    cut = np.searchsorted(b.index.values, pd.Timestamp(cfg["split"]["research_end"], tz="UTC").to_datetime64()) + 30
    b.close = b.close.copy(); b.high = b.high.copy(); b.low = b.low.copy()
    b.close[cut:] *= 1.5
    b.high[cut:] *= 1.5
    b.low[cut:] *= 0.5
    lab._trunc.clear()
    a2, *_ = lab.evaluate(p, "research")
    assert a == a2


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn()
            print("ok ", name)
