#!/usr/bin/env python3
"""Export XAUUSD M1 history from a running MetaTrader 5 terminal (Windows) to data/xauusd_m1.parquet.

  pip install MetaTrader5 pandas pyarrow
  python fetch_mt5_m1.py --symbol XAUUSD --start 2017-01-01

Pakai nama simbol persis seperti di Market Watch broker kamu (contoh: XAUUSD, XAUUSD.m, GOLD).
Catatan: broker hanya menyimpan riwayat M1 sejauh tertentu; tarik semampunya lalu cek tanggal awal.
"""
import argparse
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--symbol", default="XAUUSD")
    ap.add_argument("--start", default="2017-01-01")
    ap.add_argument("--out", default="data/xauusd_m1.parquet")
    a = ap.parse_args()

    import MetaTrader5 as mt5

    if not mt5.initialize():
        raise SystemExit(f"MT5 gagal diinisialisasi: {mt5.last_error()} — buka & login terminal MT5 dulu.")
    if not mt5.symbol_select(a.symbol, True):
        raise SystemExit(f"Simbol {a.symbol} tidak ditemukan di Market Watch.")
    start = datetime.fromisoformat(a.start).replace(tzinfo=timezone.utc)
    end = datetime.now(timezone.utc)
    chunks, cur = [], start
    while cur < end:
        nxt = min(cur + pd.Timedelta(days=90), end)
        r = mt5.copy_rates_range(a.symbol, mt5.TIMEFRAME_M1, cur, nxt)
        if r is not None and len(r):
            chunks.append(pd.DataFrame(r))
        cur = nxt
    mt5.shutdown()
    if not chunks:
        raise SystemExit("Tidak ada data yang terambil.")
    df = pd.concat(chunks).drop_duplicates("time")
    df["time"] = pd.to_datetime(df["time"], unit="s", utc=True)
    df = df.set_index("time").sort_index()[["open", "high", "low", "close", "tick_volume", "spread"]]
    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    df.to_parquet(a.out)
    print(f"{len(df):,} bar M1  {df.index[0]} → {df.index[-1]}  → {a.out}")
    print("Hapus file data/xauusd_M15/H1/H4.parquet lama agar di-resample ulang.")


if __name__ == "__main__":
    main()
