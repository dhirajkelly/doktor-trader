"""Revalidation gates. A strategy reaches paper trading only if it passes ALL of them.

  G1 OOS        : validation window Sharpe, profit factor and trade count above thresholds
  G2 DSR        : Deflated Sharpe Ratio of the in-sample returns, given N trials in the ledger
  G3 PBO        : Probability of Backtest Overfitting of the whole search (CSCV) below threshold
  G4 COST STRESS: still positive expectancy with spread x1.5 and slippage x2 (IS and OOS)
  G5 STABILITY  : most parameter neighbours are also profitable in-sample (no knife-edge optimum)
  G6 HOLDOUT    : opened ONCE, only for strategies that passed G1-G5; must keep positive
                  expectancy and stay within the Monte-Carlo drawdown band
"""
from __future__ import annotations

import json
import math
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

from . import metrics as MX
from . import strategies as S
from .lab import config_hash


def _corr(ledger, k1, k2) -> float:
    a, b = ledger.returns[k1], ledger.returns[k2]
    if a.std() == 0 or b.std() == 0:
        return 0.0
    return float(np.corrcoef(a, b)[0, 1])


def pick_finalists(ledger, n: int, per_family: int = 2) -> list[dict]:
    out, count = [], {}
    for r in ledger.leaderboard(len(ledger)):
        if r["score"] <= 0:
            break
        f = r["family"]
        if count.get(f, 0) >= per_family:
            continue
        # skip near-duplicates (same family+tf with very similar score)
        if any(_corr(ledger, o["key"], r["key"]) > 0.8 for o in out):
            continue
        out.append(r)
        count[f] = count.get(f, 0) + 1
        if len(out) >= n:
            break
    return out


def _f(x, nd=3):
    return None if x is None or (isinstance(x, float) and not math.isfinite(x)) else round(float(x), nd)


def validate_finalists(lab, ledger, cfg: dict, log=print) -> dict:
    vc = cfg["validation"]
    rng = np.random.default_rng(cfg["search"]["seed"] + 7)
    fins = pick_finalists(ledger, vc["n_finalists"])
    eff = ledger.effective_trials()
    N, var_sr = eff["n_eff"], eff["sr_var"]
    log(f"Trials: {eff['n_raw']} total → {N} independent clusters (corr > 0.5 grouped) for the DSR")
    pbo = MX.pbo_cscv(ledger.matrix(), S=16, seed=1)
    log(f"PBO (CSCV, {pbo.get('n_splits')} splits over {min(N, 1500)} trials): {pbo['pbo']:.3f}")
    g3 = bool(pbo["pbo"] <= vc["pbo_max"]) if math.isfinite(pbo["pbo"]) else False

    results = []
    for r in fins:
        p = json.loads(r["params"])
        is_stats, is_tr, is_dr = lab.evaluate(p, "research")
        oos_stats, oos_tr, oos_dr = lab.evaluate(p, "validation")
        dsr = MX.deflated_sharpe(is_dr.to_numpy(), N, var_sr)
        g1 = (oos_stats["sharpe"] >= vc["oos_min_sharpe"] and oos_stats["pf"] >= vc["oos_min_pf"]
              and oos_stats["trades"] >= vc["oos_min_trades"])
        g2 = dsr["dsr"] >= vc["dsr_min"]
        st_is, _, _ = lab.evaluate(p, "research", spread_mult=vc["stress_spread_mult"], slip_mult=vc["stress_slippage_mult"])
        st_oos, _, _ = lab.evaluate(p, "validation", spread_mult=vc["stress_spread_mult"], slip_mult=vc["stress_slippage_mult"])
        g4 = st_is["expectancy_R"] > 0 and st_oos["expectancy_R"] > 0
        nb = S.neighbours(p, rng, 16)
        nb_pos = [lab.evaluate(q, "research")[0]["expectancy_R"] > 0 for q in nb]
        stab = float(np.mean(nb_pos))
        g5 = stab >= vc["stability_min_frac"]
        mc = MX.monte_carlo_dd(oos_tr["R"].to_numpy(), lab.risk, vc["mc_runs"], seed=3)
        sl_px = float(np.median(oos_tr["risk_px"])) if len(oos_tr) else float("nan")
        res = {
            "desc": r["desc"], "family": r["family"], "tf": r["tf"], "params": p,
            "score": r["score"], "trial": r["trial"], "source": r["source"],
            "hypothesis": r.get("hypothesis"),
            "is": {k: _f(v) for k, v in is_stats.items()},
            "oos": {k: _f(v) for k, v in oos_stats.items()},
            "stress_is_expR": _f(st_is["expectancy_R"]), "stress_oos_expR": _f(st_oos["expectancy_R"]),
            "dsr": {k: _f(v, 4) for k, v in dsr.items()},
            "stability": _f(stab), "mc": mc, "median_sl_px": _f(sl_px, 2),
            "gates": {"G1_oos": bool(g1), "G2_dsr": bool(g2), "G3_pbo": g3, "G4_stress": bool(g4), "G5_stability": bool(g5)},
            "_curves": {"is": is_dr, "oos": oos_dr},
        }
        res["passed_G1_G5"] = all(res["gates"].values())
        results.append(res)
        flags = " ".join(("✔" if v else "✘") + k.split("_")[0] for k, v in res["gates"].items())
        log(f"  {r['desc'][:70]:70s} | OOS SR {oos_stats['sharpe']:+.2f} PF {oos_stats['pf']:.2f} "
            f"n={oos_stats['trades']} | DSR {dsr['dsr']:.2f} | stab {stab:.2f} | {flags}")

    return {"n_trials": N, "n_trials_raw": eff["n_raw"], "trial_sr_var": var_sr, "pbo": pbo, "finalists": results}


# ----------------------------------------------------------------------------------------------
def open_holdout(lab, val: dict, cfg: dict, out_dir: Path, log=print) -> dict:
    """Opens the holdout ONCE for strategies that passed G1-G5 and records the event."""
    lock = out_dir / "holdout_log.json"
    events = json.loads(lock.read_text()) if lock.exists() else []
    h = config_hash(cfg)
    prior = [e for e in events if e["config_hash"] == h]
    passed = [f for f in val["finalists"] if f["passed_G1_G5"]]
    status = {"opened": False, "prior_openings": len(prior), "config_hash": h}
    if not passed:
        log("Holdout stays SEALED: no strategy passed G1-G5.")
        status["reason"] = "belum ada strategi yang lolos gate G1–G5"
        return status
    if prior:
        log(f"WARNING: holdout already opened {len(prior)}x with this config → it is no longer a clean test.")
    lab.unlock_holdout()
    for f in passed:
        st, tr, dr = lab.evaluate(f["params"], "holdout")
        mc_dd95 = f["mc"]["dd_p95"]
        g6 = st["expectancy_R"] > 0 and st["max_dd"] >= mc_dd95 and st["trades"] >= 5
        f["holdout"] = {k: _f(v) for k, v in st.items()}
        f["gates"]["G6_holdout"] = bool(g6)
        f["_curves"]["holdout"] = dr
        f["approved_for_paper"] = bool(g6)
        log(f"  HOLDOUT {f['desc'][:60]:60s} | SR {st['sharpe']:+.2f} expR {st['expectancy_R']:+.3f} "
            f"DD {st['max_dd']:.1%} (MC95 {mc_dd95:.1%}) n={st['trades']} → {'PASS' if g6 else 'FAIL'}")
    events.append({"time": datetime.now(timezone.utc).isoformat(), "config_hash": h,
                   "strategies": [f["desc"] for f in passed]})
    lock.write_text(json.dumps(events, indent=1))
    status.update(opened=True, n_tested=len(passed))
    return status
