"""Data loading & resampling for XAUUSD.

Accepts:
  * Parquet with columns open/high/low/close/tick_volume/spread and a UTC DatetimeIndex
  * MT5 CSV export (History Center / "Export bars"): <DATE> <TIME> <OPEN> <HIGH> <LOW> <CLOSE> <TICKVOL> <VOL> <SPREAD>
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

TF_RULE = {"M5": "5min", "M15": "15min", "M30": "30min", "H1": "1h", "H4": "4h", "D1": "1D"}


def load_m1(path: str | Path) -> pd.DataFrame:
    path = Path(path)
    if path.suffix.lower() == ".parquet":
        df = pd.read_parquet(path)
    else:
        df = _read_mt5_csv(path)
    df = df[["open", "high", "low", "close", "tick_volume", "spread"]].copy()
    if df.index.tz is None:
        df.index = df.index.tz_localize("UTC")
    df = df[~df.index.duplicated(keep="last")].sort_index()
    # basic OHLC sanity
    bad = (df["high"] < df[["open", "close"]].max(axis=1)) | (df["low"] > df[["open", "close"]].min(axis=1))
    df = df[~bad]
    return df


def _read_mt5_csv(path: Path) -> pd.DataFrame:
    raw = pd.read_csv(path, sep=None, engine="python")
    raw.columns = [c.strip("<>").lower() for c in raw.columns]
    if "time" in raw.columns and "date" in raw.columns:
        ts = pd.to_datetime(raw["date"].astype(str) + " " + raw["time"].astype(str))
    else:
        ts = pd.to_datetime(raw[raw.columns[0]])
    raw = raw.rename(columns={"tickvol": "tick_volume", "vol": "volume"})
    if "spread" not in raw.columns:
        raw["spread"] = 0
    raw.index = ts
    return raw


def resample(m1: pd.DataFrame, tf: str) -> pd.DataFrame:
    rule = TF_RULE[tf]
    agg = {
        "open": "first",
        "high": "max",
        "low": "min",
        "close": "last",
        "tick_volume": "sum",
        "spread": "mean",  # mean of per-minute (minimum) spreads — more realistic than min
    }
    out = m1.resample(rule, label="left", closed="left").agg(agg).dropna(subset=["open"])
    return out


@dataclass
class Bars:
    """Numpy view of a bar series, ready for the numba engine."""

    tf: str
    index: pd.DatetimeIndex
    open: np.ndarray
    high: np.ndarray
    low: np.ndarray
    close: np.ndarray
    spread_px: np.ndarray  # spread in PRICE units (USD/oz) after floor & multiplier
    day_id: np.ndarray     # integer calendar day (for swap counting)
    weekday: np.ndarray
    hour: np.ndarray

    def __len__(self) -> int:
        return len(self.close)

    def slice(self, start: str, end: str) -> "Bars":
        m = (self.index >= pd.Timestamp(start, tz="UTC")) & (self.index <= pd.Timestamp(end, tz="UTC") + pd.Timedelta(days=1))
        idx = np.flatnonzero(m)
        s = slice(idx[0], idx[-1] + 1) if len(idx) else slice(0, 0)
        return Bars(self.tf, self.index[s], self.open[s], self.high[s], self.low[s], self.close[s],
                    self.spread_px[s], self.day_id[s], self.weekday[s], self.hour[s])


def to_bars(df: pd.DataFrame, tf: str, point: float, spread_floor_points: float, spread_mult: float) -> Bars:
    sp_pts = np.maximum(df["spread"].to_numpy(float) * spread_mult, spread_floor_points)
    idx = df.index
    day_id = ((idx - pd.Timestamp("1970-01-01", tz="UTC")).days).to_numpy().astype(np.int64)
    return Bars(
        tf=tf,
        index=idx,
        open=df["open"].to_numpy(float),
        high=df["high"].to_numpy(float),
        low=df["low"].to_numpy(float),
        close=df["close"].to_numpy(float),
        spread_px=sp_pts * point,
        day_id=day_id,
        weekday=idx.weekday.to_numpy().astype(np.int64),
        hour=idx.hour.to_numpy().astype(np.int64),
    )


def build_timeframes(m1_path: str | Path, tfs: list[str], cache_dir: str | Path = "data") -> dict[str, pd.DataFrame]:
    cache_dir = Path(cache_dir)
    out: dict[str, pd.DataFrame] = {}
    m1 = None
    for tf in tfs:
        p = cache_dir / f"xauusd_{tf}.parquet"
        if p.exists():
            out[tf] = pd.read_parquet(p)
            continue
        if m1 is None:
            m1 = load_m1(m1_path)
        out[tf] = resample(m1, tf)
        out[tf].to_parquet(p)
    return out
