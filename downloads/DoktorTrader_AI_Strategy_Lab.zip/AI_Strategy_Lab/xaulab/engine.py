"""Bar-by-bar backtest engine (numba) with realistic XAUUSD execution.

Conventions
-----------
* Bars are BID prices (MT5 default). Ask = bid + spread.
* A signal computed on the CLOSE of bar i is executed at the OPEN of bar i+1 (no look-ahead).
* Long: buy at ask (+slippage), exits at bid. Short: sell at bid (-slippage), exits at ask.
* SL and TP checked intrabar with high/low. If both could be hit in the same bar → SL is assumed
  (conservative). Gaps through SL fill at the open (worse price).
* Swap charged per rollover (calendar-day change between bars), triple on `triple_wd`.
* Everything is in USD per 1 oz. R-multiple = net PnL / initial stop distance.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
from numba import njit

EXIT_SL, EXIT_TP, EXIT_TIME, EXIT_END = 0, 1, 2, 3


@njit(cache=True)
def run_engine(open_, high, low, close, spread, day_id, weekday,
               signal, sl_dist, rr, max_hold,
               slip, comm, swap_long, swap_short, triple_wd):
    m = len(close)
    cap = m // 2 + 1
    t_entry = np.empty(cap, np.int64)
    t_exit = np.empty(cap, np.int64)
    t_dir = np.empty(cap, np.int64)
    t_pnl = np.empty(cap)
    t_R = np.empty(cap)
    t_risk = np.empty(cap)
    t_reason = np.empty(cap, np.int64)
    n = 0

    in_pos = 0
    entry_px = 0.0
    sl = 0.0
    tp = 0.0
    dist = 0.0
    e_idx = 0
    swap_acc = 0.0

    i = 0
    while i < m:
        if in_pos == 0:
            s = signal[i]
            d = sl_dist[i]
            if i < m - 1 and s != 0 and d > 0 and not np.isnan(d):
                j = i + 1
                if s > 0:
                    entry_px = open_[j] + spread[j] + slip
                    sl = entry_px - d
                    tp = entry_px + rr * d
                else:
                    entry_px = open_[j] - slip
                    sl = entry_px + d
                    tp = entry_px - rr * d
                dist = d
                in_pos = s
                e_idx = j
                swap_acc = 0.0
                i = j
                # fall through to manage the position on the entry bar itself
            else:
                i += 1
                continue

        # ---- manage open position on bar i ----
        if i > e_idx and day_id[i] != day_id[i - 1]:
            mult = 3.0 if weekday[i - 1] == triple_wd else 1.0
            swap_acc += (swap_long if in_pos > 0 else swap_short) * mult

        exit_px = 0.0
        reason = -1
        if in_pos > 0:
            o = open_[i]
            if i > e_idx and o <= sl:
                exit_px = o - slip
                reason = EXIT_SL
            elif low[i] <= sl:
                exit_px = sl - slip
                reason = EXIT_SL
            elif high[i] >= tp:
                exit_px = tp
                reason = EXIT_TP
        else:
            ao = open_[i] + spread[i]
            if i > e_idx and ao >= sl:
                exit_px = ao + slip
                reason = EXIT_SL
            elif high[i] + spread[i] >= sl:
                exit_px = sl + slip
                reason = EXIT_SL
            elif low[i] + spread[i] <= tp:
                exit_px = tp
                reason = EXIT_TP

        if reason < 0 and (i - e_idx) >= max_hold:
            if in_pos > 0:
                exit_px = close[i] - slip
            else:
                exit_px = close[i] + spread[i] + slip
            reason = EXIT_TIME
        if reason < 0 and i == m - 1:
            if in_pos > 0:
                exit_px = close[i] - slip
            else:
                exit_px = close[i] + spread[i] + slip
            reason = EXIT_END

        if reason >= 0:
            gross = (exit_px - entry_px) if in_pos > 0 else (entry_px - exit_px)
            pnl = gross - comm + swap_acc
            t_entry[n] = e_idx
            t_exit[n] = i
            t_dir[n] = in_pos
            t_pnl[n] = pnl
            t_R[n] = pnl / dist
            t_risk[n] = dist
            t_reason[n] = reason
            n += 1
            in_pos = 0
        i += 1

    return (t_entry[:n], t_exit[:n], t_dir[:n], t_pnl[:n], t_R[:n], t_risk[:n], t_reason[:n])


@dataclass
class CostModel:
    slip_px: float
    comm_px: float        # per oz, round turn
    swap_long_px: float   # per oz per night
    swap_short_px: float
    triple_wd: int

    @classmethod
    def from_cfg(cls, c: dict, point: float, slip_mult: float = 1.0) -> "CostModel":
        return cls(
            slip_px=c["slippage_points"] * point * slip_mult,
            comm_px=c["commission_per_lot"] / 100.0,
            swap_long_px=c["swap_long_per_lot"] / 100.0,
            swap_short_px=c["swap_short_per_lot"] / 100.0,
            triple_wd=int(c["triple_swap_weekday"]),
        )


def backtest(bars, signal: np.ndarray, sl_dist: np.ndarray, rr: float, max_hold: int, cost: CostModel,
             spread_override: np.ndarray | None = None) -> pd.DataFrame:
    sp = bars.spread_px if spread_override is None else spread_override
    te, tx, td, pnl, R, risk, reason = run_engine(
        bars.open, bars.high, bars.low, bars.close, sp, bars.day_id, bars.weekday,
        signal.astype(np.int64), sl_dist.astype(np.float64), float(rr), int(max_hold),
        cost.slip_px, cost.comm_px, cost.swap_long_px, cost.swap_short_px, cost.triple_wd,
    )
    return pd.DataFrame({
        "entry_time": bars.index[te], "exit_time": bars.index[tx],
        "entry_i": te, "exit_i": tx, "dir": td, "pnl_px": pnl, "R": R, "risk_px": risk, "reason": reason,
    })
