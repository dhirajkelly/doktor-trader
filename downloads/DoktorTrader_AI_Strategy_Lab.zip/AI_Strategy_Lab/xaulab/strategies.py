"""Strategy families + parameter spaces.

Each family turns a parameter dict into (signal, sl_dist) arrays on a Bars object.
signal[i] = +1/-1 means "enter at the next bar's open". sl_dist[i] is the stop distance in USD/oz.

Parameter spaces are explicit and bounded: neither the evolutionary search nor the LLM agent can
invent free-form code — they can only pick points inside these spaces. That keeps the trial count
honest (needed for the Deflated Sharpe Ratio) and makes every result reproducible.
"""
from __future__ import annotations

import numpy as np
from numba import njit

from . import indicators as ind

# ----------------------------------------------------------------------------------------------
# parameter spaces: name -> (kind, low, high[, step]) or ("choice", [options])
# ----------------------------------------------------------------------------------------------
COMMON = {
    "atr_sl": ("float", 0.8, 4.0, 0.1),
    "rr": ("float", 0.8, 4.0, 0.1),
    "max_hold": ("int", 8, 240, 4),
    "direction": ("choice", ["both", "long", "short"]),
    "session": ("choice", ["all", "london_ny", "london", "ny"]),
}

SPACES: dict[str, dict] = {
    "ema_trend": {
        "tf": ("choice", ["M15", "H1", "H4"]),
        "fast": ("int", 5, 60, 1),
        "slow": ("int", 20, 250, 5),
        "adx_min": ("choice", [0, 15, 20, 25, 30]),
        **COMMON,
    },
    "donchian": {
        "tf": ("choice", ["M15", "H1", "H4"]),
        "n": ("int", 10, 120, 2),
        "trend_ema": ("choice", [0, 50, 100, 200, 300]),
        **COMMON,
    },
    "rsi_revert": {
        "tf": ("choice", ["M15", "H1", "H4"]),
        "rsi_len": ("int", 2, 21, 1),
        "lo": ("int", 5, 35, 1),
        "trend_ema": ("choice", [0, 100, 200, 300]),
        **COMMON,
    },
    "session_break": {
        "tf": ("choice", ["M15", "H1"]),
        "range_end_h": ("int", 4, 8, 1),          # Asian range 00:00 -> range_end_h (server/UTC)
        "trade_until_h": ("int", 10, 20, 1),
        "buffer_atr": ("float", 0.0, 0.5, 0.05),
        "sl_frac": ("float", 0.3, 1.2, 0.05),     # SL = sl_frac * range width (min 0.5 ATR)
        "rr": ("float", 0.8, 4.0, 0.1),
        "max_hold": ("int", 8, 120, 4),
        "direction": ("choice", ["both", "long", "short"]),
    },
}

SESSION_HOURS = {
    "all": (0, 24),
    "london": (7, 16),
    "ny": (12, 21),
    "london_ny": (7, 21),
}


def describe(family: str, p: dict) -> str:
    keys = [k for k in SPACES[family] if k not in ("tf",)]
    return f"{family}[{p['tf']}] " + " ".join(f"{k}={p[k]}" for k in keys)


# ----------------------------------------------------------------------------------------------
# indicator cache (per Bars object)
# ----------------------------------------------------------------------------------------------
class Cache:
    def __init__(self, bars):
        self.b = bars
        self.d: dict = {}

    def get(self, key, fn):
        if key not in self.d:
            self.d[key] = fn()
        return self.d[key]

    def ema(self, n):
        return self.get(("ema", n), lambda: ind.ema(self.b.close, n))

    def atr(self, n=14):
        return self.get(("atr", n), lambda: ind.atr(self.b.high, self.b.low, self.b.close, n))

    def rsi(self, n):
        return self.get(("rsi", n), lambda: ind.rsi(self.b.close, n))

    def adx(self, n=14):
        return self.get(("adx", n), lambda: ind.adx(self.b.high, self.b.low, self.b.close, n))

    def hh(self, n):
        return self.get(("hh", n), lambda: ind.rolling_max_prev(self.b.high, n))

    def ll(self, n):
        return self.get(("ll", n), lambda: ind.rolling_min_prev(self.b.low, n))


def _filters(sig: np.ndarray, bars, p: dict) -> np.ndarray:
    d = p.get("direction", "both")
    if d == "long":
        sig = np.where(sig > 0, sig, 0)
    elif d == "short":
        sig = np.where(sig < 0, sig, 0)
    ses = p.get("session", "all")
    if ses != "all":
        h0, h1 = SESSION_HOURS[ses]
        # signal is acted on at the NEXT bar; filter on the bar where the signal forms
        ok = (bars.hour >= h0) & (bars.hour < h1)
        sig = np.where(ok, sig, 0)
    return sig.astype(np.int64)


def gen_ema_trend(c: Cache, p: dict):
    b = c.b
    fast, slow = int(p["fast"]), int(p["slow"])
    if slow <= fast * 1.5:
        slow = int(fast * 1.5) + 1
    ef, es = c.ema(fast), c.ema(slow)
    diff = ef - es
    prev = np.roll(diff, 1)
    prev[0] = np.nan
    sig = np.zeros(len(b), np.int64)
    sig[(diff > 0) & (prev <= 0)] = 1
    sig[(diff < 0) & (prev >= 0)] = -1
    if p["adx_min"]:
        sig[~(c.adx() >= p["adx_min"])] = 0
    sl = c.atr() * p["atr_sl"]
    return _filters(sig, b, p), sl


def gen_donchian(c: Cache, p: dict):
    b = c.b
    n = int(p["n"])
    hh, ll = c.hh(n), c.ll(n)
    cl = b.close
    prev_cl = np.roll(cl, 1)
    prev_hh = np.roll(hh, 1)
    prev_ll = np.roll(ll, 1)
    sig = np.zeros(len(b), np.int64)
    sig[(cl > hh) & ~(prev_cl > prev_hh)] = 1
    sig[(cl < ll) & ~(prev_cl < prev_ll)] = -1
    sig[0] = 0
    if p["trend_ema"]:
        e = c.ema(int(p["trend_ema"]))
        sig[(sig > 0) & ~(cl > e)] = 0
        sig[(sig < 0) & ~(cl < e)] = 0
    sl = c.atr() * p["atr_sl"]
    return _filters(sig, b, p), sl


def gen_rsi_revert(c: Cache, p: dict):
    b = c.b
    r = c.rsi(int(p["rsi_len"]))
    lo = float(p["lo"])
    hi = 100.0 - lo
    pr = np.roll(r, 1)
    pr[0] = np.nan
    sig = np.zeros(len(b), np.int64)
    sig[(r < lo) & (pr >= lo)] = 1
    sig[(r > hi) & (pr <= hi)] = -1
    if p["trend_ema"]:
        e = c.ema(int(p["trend_ema"]))
        sig[(sig > 0) & ~(b.close > e)] = 0
        sig[(sig < 0) & ~(b.close < e)] = 0
    sl = c.atr() * p["atr_sl"]
    return _filters(sig, b, p), sl


@njit(cache=True)
def _session_break(high, low, close, hour, day_id, atr, range_end_h, trade_until_h, buffer_atr, sl_frac):
    m = len(close)
    sig = np.zeros(m, np.int64)
    sl = np.full(m, np.nan)
    cur_day = -1
    rh = -1e18
    rl = 1e18
    traded = False
    for i in range(m):
        if day_id[i] != cur_day:
            cur_day = day_id[i]
            rh = -1e18
            rl = 1e18
            traded = False
        h = hour[i]
        if h < range_end_h:
            if high[i] > rh:
                rh = high[i]
            if low[i] < rl:
                rl = low[i]
            continue
        if traded or h >= trade_until_h or rh < -1e17 or np.isnan(atr[i]):
            continue
        width = rh - rl
        buf = buffer_atr * atr[i]
        d = max(sl_frac * width, 0.5 * atr[i])
        if close[i] > rh + buf:
            sig[i] = 1
            sl[i] = d
            traded = True
        elif close[i] < rl - buf:
            sig[i] = -1
            sl[i] = d
            traded = True
    return sig, sl


def gen_session_break(c: Cache, p: dict):
    b = c.b
    sig, sl = _session_break(b.high, b.low, b.close, b.hour, b.day_id, c.atr(),
                             int(p["range_end_h"]), int(p["trade_until_h"]),
                             float(p["buffer_atr"]), float(p["sl_frac"]))
    q = dict(p)
    q["session"] = "all"
    return _filters(sig, b, q), sl


GENERATORS = {
    "ema_trend": gen_ema_trend,
    "donchian": gen_donchian,
    "rsi_revert": gen_rsi_revert,
    "session_break": gen_session_break,
}


# ----------------------------------------------------------------------------------------------
# sampling / mutation inside the spaces
# ----------------------------------------------------------------------------------------------
def _snap(spec, v):
    kind = spec[0]
    if kind == "choice":
        return v if v in spec[1] else spec[1][0]
    lo, hi, step = spec[1], spec[2], spec[3]
    v = min(max(v, lo), hi)
    v = lo + round((v - lo) / step) * step
    if kind == "int":
        return int(round(v))
    return round(float(v), 4)


def repair(p: dict) -> dict:
    """Enforce cross-parameter constraints so every trial is a distinct, meaningful strategy."""
    if p.get("family") == "ema_trend" and p["slow"] < p["fast"] * 1.5:
        p["slow"] = _snap(SPACES["ema_trend"]["slow"], p["fast"] * 1.5 + 5)
        if p["slow"] < p["fast"] * 1.5:  # fast too large for the slow range
            p["fast"] = _snap(SPACES["ema_trend"]["fast"], p["slow"] / 1.5 - 1)
    return p


def sample(family: str, rng: np.random.Generator) -> dict:
    p = {"family": family}
    for k, spec in SPACES[family].items():
        if spec[0] == "choice":
            p[k] = spec[1][rng.integers(len(spec[1]))]
        else:
            p[k] = _snap(spec, rng.uniform(spec[1], spec[2]))
    return repair(p)


def mutate(p: dict, rng: np.random.Generator, rate: float) -> dict:
    fam = p["family"]
    q = dict(p)
    for k, spec in SPACES[fam].items():
        if rng.random() > rate:
            continue
        if spec[0] == "choice":
            q[k] = spec[1][rng.integers(len(spec[1]))]
        else:
            span = spec[2] - spec[1]
            q[k] = _snap(spec, q[k] + rng.normal(0, 0.15 * span))
    return repair(q)


def crossover(a: dict, b: dict, rng: np.random.Generator) -> dict:
    if a["family"] != b["family"]:
        return dict(a)
    return repair({k: (a[k] if rng.random() < 0.5 else b[k]) for k in a})


def validate(p: dict) -> dict | None:
    """Coerce an external (e.g. LLM-proposed) param dict into the space. Returns None if invalid."""
    fam = p.get("family")
    if fam not in SPACES:
        return None
    q = {"family": fam}
    for k, spec in SPACES[fam].items():
        if k not in p:
            return None
        v = p[k]
        if spec[0] == "choice":
            if v not in spec[1]:
                return None
            q[k] = v
        else:
            try:
                q[k] = _snap(spec, float(v))
            except (TypeError, ValueError):
                return None
    return repair(q)


def neighbours(p: dict, rng: np.random.Generator, k: int = 16) -> list[dict]:
    """Small perturbations (±~10% of range on numeric params) for the stability test."""
    fam = p["family"]
    out = []
    for _ in range(k):
        q = dict(p)
        for key, spec in SPACES[fam].items():
            if spec[0] in ("int", "float"):
                span = spec[2] - spec[1]
                q[key] = _snap(spec, q[key] + rng.uniform(-0.1, 0.1) * span)
        out.append(repair(q))
    return out


def key(p: dict) -> str:
    return "|".join(f"{k}={p[k]}" for k in sorted(p))
