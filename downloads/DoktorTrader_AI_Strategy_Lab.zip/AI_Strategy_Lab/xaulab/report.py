"""Self-contained HTML report + results.json (consumed by the Doktor Trader 'AI Strategy Lab' page)."""
from __future__ import annotations

import base64
import html
import io
import json
import math
from datetime import datetime, timezone
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.dates as mdates  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

from .sizing import setup_card  # noqa: E402

BLUE, ORANGE, AQUA, GRAY = "#2a78d6", "#eb6834", "#1baf7a", "#8a8984"
INK, INK2, SURF = "#0b0b0b", "#52514e", "#fcfcfb"
GOOD, CRIT = "#0ca30c", "#d03b3b"

GATE_LABEL = {
    "G1_oos": "Out-of-sample", "G2_dsr": "Deflated Sharpe", "G3_pbo": "PBO (overfit)",
    "G4_stress": "Stress biaya", "G5_stability": "Stabilitas param", "G6_holdout": "Holdout",
}


def _style(ax):
    ax.set_facecolor(SURF)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    for s in ("left", "bottom"):
        ax.spines[s].set_color("#d8d7d2")
    ax.tick_params(colors=INK2, labelsize=8)
    ax.grid(axis="y", color="#ecebe7", lw=0.8)
    ax.set_axisbelow(True)


def _png(fig) -> str:
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=130, bbox_inches="tight", facecolor=SURF)
    plt.close(fig)
    return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()


def chart_progress(history: list[dict]) -> str:
    g = [h["gen"] for h in history]
    fig, ax = plt.subplots(figsize=(7.5, 3.0))
    _style(ax)
    ax.plot(g, [h["best_score_ever"] for h in history], color=BLUE, lw=2, marker="o", ms=4, label="Skor terbaik sejauh ini")
    ax.plot(g, [h["gen_median"] for h in history], color=ORANGE, lw=2, marker="o", ms=4, label="Median generasi")
    ax.axhline(0, color=GRAY, lw=0.8)
    ax.set_xlabel("Generasi", color=INK2, fontsize=8)
    ax.set_ylabel("Skor robustness (in-sample)", color=INK2, fontsize=8)
    ax.legend(frameon=False, fontsize=8, loc="lower right")
    return _png(fig)


def chart_hist(ledger) -> str:
    s = np.array([r["score"] for r in ledger.rows])
    fig, ax = plt.subplots(figsize=(7.5, 2.6))
    _style(ax)
    s = np.clip(s, -5, 3)
    ax.hist(s[s <= 0], bins=40, range=(-5, 3), color=GRAY, edgecolor=SURF, lw=1)
    ax.hist(s[s > 0], bins=40, range=(-5, 3), color=BLUE, edgecolor=SURF, lw=1)
    ax.axvline(0, color=INK2, lw=0.8)
    ax.set_xlabel("Skor robustness per trial (abu = negatif, biru = positif)", color=INK2, fontsize=8)
    ax.set_ylabel("Jumlah trial", color=INK2, fontsize=8)
    return _png(fig)


def _equity(curves: dict) -> pd.Series:
    parts = [curves[k] for k in ("is", "oos", "holdout") if k in curves]
    dr = pd.concat(parts)
    dr = dr[~dr.index.duplicated()]
    return (1 + dr).cumprod()


def chart_equity(f: dict, win: dict) -> str:
    eq = _equity(f["_curves"])
    fig, ax = plt.subplots(figsize=(7.5, 2.4))
    _style(ax)
    ax.plot(eq.index, eq.values, color=BLUE, lw=1.6)
    for name, (a, b), col in (("Validasi", win["validation"], "#f3efe4"), ("Holdout", win["holdout"], "#e8f1fb")):
        if name == "Holdout" and "holdout" not in f["_curves"]:
            continue
        ax.axvspan(pd.Timestamp(a), min(pd.Timestamp(b), eq.index[-1]), color=col, zorder=0)
        ax.text(pd.Timestamp(a), ax.get_ylim()[1], f" {name}", va="top", fontsize=7, color=INK2)
    ax.axhline(1, color=GRAY, lw=0.6)
    ax.yaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, _: f"{(v - 1) * 100:+.0f}%"))
    ax.xaxis.set_major_locator(mdates.YearLocator())
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
    ax.set_ylabel("Ekuitas (risk 1%/trade)", color=INK2, fontsize=8)
    return _png(fig)


def _pct(x, nd=1):
    return "–" if x is None else f"{x * 100:.{nd}f}%"


def _num(x, nd=2):
    return "–" if x is None or (isinstance(x, float) and not math.isfinite(x)) else f"{x:.{nd}f}"


def build(out_dir: Path, cfg: dict, lab, ledger, history, val: dict, hold: dict) -> dict:
    out_dir.mkdir(parents=True, exist_ok=True)
    rc = cfg["risk"]
    fins = val["finalists"]
    now = datetime.now(timezone.utc)
    data_end = str(lab.window_end("holdout").date())

    # ------------------------------------------------------------------ results.json (for web)
    def weekly(f):
        eq = _equity(f["_curves"]).resample("W").last().dropna()
        return [[d.strftime("%Y-%m-%d"), round(float(v), 4)] for d, v in eq.items()]

    approved = [f for f in fins if f.get("approved_for_paper")]
    for f in fins:
        sl = f["median_sl_px"] or 0
        f["setup_card"] = setup_card(rc["account_equity"], rc["risk_per_trade"], sl, f["params"]["rr"],
                                     contract=rc["contract_size"], min_lot=rc["min_lot"], step=rc["lot_step"])
    results = {
        "generated_at": now.isoformat(timespec="seconds"),
        "data": {"symbol": "XAUUSD", "source": "Exness MT5 M1 (XAUUSDm), di-resample ke M15/H1/H4",
                 "start": str(lab.full["H1"].index[0].date()), "end": data_end},
        "windows": {k: list(v) for k, v in lab.win.items()},
        "costs": cfg["costs"],
        "search": {"generations": len(history), "trials": len(ledger), "families": list({r["family"] for r in ledger.rows}),
                   "llm_agent": bool(cfg["search"].get("use_llm_agent")),
                   "llm_proposals": int(sum(h.get("llm_proposals", 0) for h in history)),
                   "positive_score_share": round(float(np.mean([r["score"] > 0 for r in ledger.rows])), 3),
                   "progress": [{k: (round(v, 4) if isinstance(v, float) else v) for k, v in h.items()} for h in history]},
        "dsr_trials": {"independent": val["n_trials"], "raw": val["n_trials_raw"]},
        "pbo": {k: (round(v, 4) if isinstance(v, float) else v) for k, v in val["pbo"].items()},
        "holdout": hold,
        "finalists": [{k: v for k, v in f.items() if k != "_curves"} | {"equity_weekly": weekly(f)} for f in fins],
        "approved": [f["desc"] for f in approved],
    }
    (out_dir / "results.json").write_text(json.dumps(results, indent=1, default=str))

    # ------------------------------------------------------------------ HTML
    rows = []
    for i, f in enumerate(fins, 1):
        g = f["gates"]
        cells = "".join(
            f'<td class="{ "ok" if g.get(k) else ("na" if k not in g else "no") }">'
            f'{"✓" if g.get(k) else ("–" if k not in g else "✗")}</td>' for k in GATE_LABEL)
        rows.append(f"<tr><td>{i}</td><td class='l'>{html.escape(f['desc'])}</td>"
                    f"<td>{_num(f['is']['sharpe'])}</td><td>{_num(f['oos']['sharpe'])}</td><td>{_num(f['oos']['pf'])}</td>"
                    f"<td>{int(f['oos']['trades'])}</td><td>{_num(f['dsr']['dsr'])}</td><td>{_num(f['stability'])}</td>{cells}</tr>")
    gate_head = "".join(f"<th>{v}</th>" for v in GATE_LABEL.values())

    cards = []
    for f in fins:
        sc = f["setup_card"]
        verdict = ("<span class='badge ok'>LOLOS SEMUA GATE → boleh paper trading</span>" if f.get("approved_for_paper")
                   else "<span class='badge no'>BELUM LOLOS → tidak untuk dipakai</span>")
        hold_row = ""
        if "holdout" in f:
            h = f["holdout"]
            hold_row = (f"<tr><th>Holdout</th><td>{_num(h['sharpe'])}</td><td>{_num(h['pf'])}</td><td>{_num(h['expectancy_R'], 3)}</td>"
                        f"<td>{_pct(h['win_rate'], 0)}</td><td>{_pct(h['max_dd'])}</td><td>{int(h['trades'])}</td></tr>")
        hyp = f"<p class='hyp'>Hipotesis agen: {html.escape(f['hypothesis'])}</p>" if f.get("hypothesis") else ""
        cards.append(f"""
<div class="card">
 <h3>{html.escape(f['desc'])}</h3>{verdict}{hyp}
 <img src="{chart_equity(f, lab.win)}" alt="kurva ekuitas">
 <table class="m"><tr><th></th><th>Sharpe</th><th>PF</th><th>Exp. R</th><th>Win</th><th>Max DD</th><th>Trade</th></tr>
 <tr><th>Riset (IS)</th><td>{_num(f['is']['sharpe'])}</td><td>{_num(f['is']['pf'])}</td><td>{_num(f['is']['expectancy_R'], 3)}</td><td>{_pct(f['is']['win_rate'], 0)}</td><td>{_pct(f['is']['max_dd'])}</td><td>{int(f['is']['trades'])}</td></tr>
 <tr><th>Validasi (OOS)</th><td>{_num(f['oos']['sharpe'])}</td><td>{_num(f['oos']['pf'])}</td><td>{_num(f['oos']['expectancy_R'], 3)}</td><td>{_pct(f['oos']['win_rate'], 0)}</td><td>{_pct(f['oos']['max_dd'])}</td><td>{int(f['oos']['trades'])}</td></tr>
 {hold_row}</table>
 <p class="small">DSR {_num(f['dsr']['dsr'])} (Sharpe tahunan IS {_num(f['dsr'].get('sr_ann'))} vs ambang kebetulan {_num(f['dsr'].get('sr0_ann'))} dari {val['n_trials']} kelompok ide independen / {val['n_trials_raw']} trial) ·
 Stress biaya exp R: IS {_num(f['stress_is_expR'], 3)} / OOS {_num(f['stress_oos_expR'], 3)} ·
 Monte Carlo DD p95 {_pct(f['mc']['dd_p95'])}, losing streak p95 {f['mc'].get('streak_p95')}</p>
 <p class="small"><b>Kartu sizing (contoh, bukan sinyal):</b> ekuitas ${sc['equity']:,.0f}, risk {sc['risk_pct']:.1f}% =
 ${sc['risk_usd']:.0f} · SL median ${sc['sl_usd_per_oz']:.2f}/oz · TP ${sc['tp_usd_per_oz']:.2f}/oz ·
 <b>Lot {sc['lot']:.2f}</b> (risiko aktual ${sc['actual_risk_usd']:.0f}) · <b>RR {sc['rr']}</b> {html.escape(sc['note'])}</p>
</div>""")

    pbo = val["pbo"]
    n_pass = sum(f["passed_G1_G5"] for f in fins)
    hold_txt = (f"Dibuka untuk {hold.get('n_tested')} strategi; {len(approved)} lolos." if hold.get("opened")
                else f"TETAP TERSEGEL — {html.escape(hold.get('reason', ''))}.")
    if hold.get("prior_openings"):
        hold_txt += f" ⚠ Holdout sudah pernah dibuka {hold['prior_openings']}x dengan konfigurasi ini."

    page = f"""<!DOCTYPE html><html lang="id"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>AI Strategy Lab — Laporan Riset XAUUSD</title>
<style>
body{{font-family:-apple-system,Segoe UI,Roboto,sans-serif;background:#f9f9f7;color:{INK};margin:0;padding:24px;line-height:1.5}}
.wrap{{max-width:980px;margin:auto}} h1{{margin:0 0 4px}} h2{{margin-top:36px;border-bottom:1px solid #e3e2dd;padding-bottom:6px}}
.sub{{color:{INK2}}} .kpis{{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px;margin:18px 0}}
.kpi{{background:#fff;border:1px solid #e6e5e0;border-radius:10px;padding:12px}} .kpi b{{font-size:24px;display:block}}
.kpi span{{color:{INK2};font-size:13px}} img{{width:100%;border-radius:8px;border:1px solid #eee}}
table{{border-collapse:collapse;width:100%;font-size:13px;background:#fff}} th,td{{padding:6px 8px;border-bottom:1px solid #eee;text-align:center}}
td.l{{text-align:left}} td.ok{{color:{GOOD};font-weight:700}} td.no{{color:{CRIT};font-weight:700}} td.na{{color:#aaa}}
.card{{background:#fff;border:1px solid #e6e5e0;border-radius:12px;padding:16px;margin:16px 0}} .card h3{{margin:0 0 6px;font-size:15px}}
.badge{{display:inline-block;padding:3px 10px;border-radius:999px;font-size:12px;font-weight:700;margin-bottom:8px}}
.badge.ok{{background:#e5f5e5;color:#075f07}} .badge.no{{background:#fbe9e9;color:#9b2222}}
.small{{font-size:12.5px;color:{INK2}}} .hyp{{font-style:italic;color:{INK2};font-size:13px}} table.m th{{text-align:left}}
.warn{{background:#fff7e6;border:1px solid #f3d9a4;border-radius:10px;padding:12px;font-size:13px}}
.scroll{{overflow-x:auto}}
</style></head><body><div class="wrap">
<h1>AI Strategy Lab — Laporan Riset XAUUSD</h1>
<div class="sub">Dibuat {now:%d %b %Y %H:%M} UTC · Data {results['data']['source']} · {results['data']['start']} → {data_end}</div>

<div class="kpis">
 <div class="kpi"><b>{len(ledger):,}</b><span>strategi diuji ({len(history)} generasi)</span></div>
 <div class="kpi"><b>{results['search']['positive_score_share'] * 100:.0f}%</b><span>trial dengan skor positif di data riset</span></div>
 <div class="kpi"><b>{n_pass} / {len(fins)}</b><span>finalis lolos gate G1–G5</span></div>
 <div class="kpi"><b>{len(approved)}</b><span>disetujui untuk paper trading</span></div>
 <div class="kpi"><b>{_num(pbo['pbo'])}</b><span>Probability of Backtest Overfitting</span></div>
</div>

<div class="warn"><b>Baca dulu:</b> ini hasil backtest historis (hipotetis), bukan jaminan dan bukan sinyal beli/jual.
Biaya dimodelkan: spread asli MT5 (min {cfg['costs']['spread_floor_points'] * cfg['data']['point']:.2f} USD), slippage {cfg['costs']['slippage_points'] * cfg['data']['point']:.2f} USD per sisi,
swap long {cfg['costs']['swap_long_per_lot']} / short {cfg['costs']['swap_short_per_lot']} USD per lot per malam (asumsi). Strategi yang lolos semua gate
pun wajib diuji di akun demo dulu.</div>

<h2>1. Loop self-improvement</h2>
<p>Setiap generasi: elite dipertahankan, sisanya diganti mutasi, persilangan, ide acak{', dan usulan agen AI' if results['search']['llm_agent'] else ''}.
Semua trial dicatat di ledger. Makin banyak ide yang dicoba, makin tinggi ambang Deflated Sharpe yang harus dilewati.</p>
<img src="{chart_progress(history)}" alt="progres skor per generasi">
<img src="{chart_hist(ledger)}" alt="distribusi skor trial" style="margin-top:10px">

<h2>2. Gate validasi</h2>
<p>PBO dari seluruh pencarian: <b>{_num(pbo['pbo'])}</b> ({pbo.get('n_splits')} split CSCV). Artinya, di {_num((pbo['pbo'] or 0) * 100, 0)}% split,
strategi terbaik di satu separuh data berada di bawah median di separuh lainnya. Holdout: {hold_txt}</p>
<div class="scroll"><table><tr><th>#</th><th>Strategi</th><th>SR IS</th><th>SR OOS</th><th>PF OOS</th><th>Trade OOS</th><th>DSR</th><th>Stab.</th>{gate_head}</tr>
{''.join(rows)}</table></div>

<h2>3. Detail finalis</h2>
{''.join(cards)}

<h2>4. Metodologi singkat</h2>
<ul class="small">
<li>Riset {lab.win['research'][0]} → {lab.win['research'][1]} · Validasi {lab.win['validation'][0]} → {lab.win['validation'][1]} · Holdout {lab.win['holdout'][0]} → {data_end}. Agen AI dan loop hanya melihat data riset.</li>
<li>Eksekusi: sinyal di close bar, masuk di open bar berikutnya; harga bid + spread untuk ask; SL/TP dicek intrabar, bila keduanya kena di bar yang sama dianggap SL.</li>
<li>Skor robustness = rata-rata Sharpe per tahun − 0,5 × deviasinya, dengan penalti trade terlalu sedikit dan drawdown &gt; 30%.</li>
<li>DSR (Bailey & López de Prado 2014), PBO via CSCV 16 blok (Bailey dkk. 2015), stress biaya spread ×{cfg['validation']['stress_spread_mult']} & slippage ×{cfg['validation']['stress_slippage_mult']}, stabilitas 16 tetangga parameter ±10%, Monte Carlo {cfg['validation']['mc_runs']} resample.</li>
</ul>
</div></body></html>"""
    (out_dir / "report.html").write_text(page, encoding="utf-8")
    return results
