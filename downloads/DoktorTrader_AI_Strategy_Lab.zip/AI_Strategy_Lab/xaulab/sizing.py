"""Lot sizing for XAUUSD (1 lot = 100 oz → $1 move = $100 per lot)."""
from __future__ import annotations

import math


def lot_size(equity: float, risk_frac: float, sl_px: float, contract: float = 100,
             min_lot: float = 0.01, step: float = 0.01) -> dict:
    risk_usd = equity * risk_frac
    if sl_px <= 0:
        return {"lot": 0.0, "risk_usd": risk_usd, "actual_risk_usd": 0.0, "note": "invalid SL"}
    raw = risk_usd / (sl_px * contract)
    lot = math.floor(raw / step + 1e-9) * step
    note = ""
    if lot < min_lot:
        lot = 0.0
        note = f"SL ${sl_px:.2f} too wide for this equity at {risk_frac:.1%} risk — even {min_lot} lot exceeds it"
    lot = round(lot, 2)
    return {"lot": lot, "risk_usd": round(risk_usd, 2),
            "actual_risk_usd": round(lot * sl_px * contract, 2), "raw_lot": round(raw, 4), "note": note}


def setup_card(equity: float, risk_frac: float, sl_px: float, rr: float, **kw) -> dict:
    ls = lot_size(equity, risk_frac, sl_px, **kw)
    return {
        "equity": equity, "risk_pct": risk_frac * 100, "sl_usd_per_oz": round(sl_px, 2),
        "tp_usd_per_oz": round(sl_px * rr, 2), "rr": f"1:{rr:g}", **ls,
        "potential_reward_usd": round(ls["lot"] * sl_px * rr * kw.get("contract", 100), 2),
    }
