"""The self-improvement loop (research window ONLY).

Generation g:
  1. Research  — new candidates come from: elites' mutations, crossovers, random immigrants,
                 and (optionally) the LLM researcher's hypotheses.
  2. Develop   — each candidate is a point in a fixed strategy space (no free-form code).
  3. Test      — backtest on the research window with full costs.
  4. Evaluate  — robustness score across years (not total profit).
  5. Improve   — elites survive; the rest is replaced next generation.
Every single trial is written to the ledger: the ledger size N feeds the Deflated Sharpe Ratio, so
the loop pays a statistical price for every idea it tries.
"""
from __future__ import annotations

import json
import math
import time
from pathlib import Path

import numpy as np
import pandas as pd

from . import agent_llm
from . import metrics as MX
from . import strategies as S

META_KEYS = ("_hypothesis", "_source")


def clean(p: dict) -> dict:
    return {k: v for k, v in p.items() if k not in META_KEYS}


def robustness_score(stats: dict, ys: list[float], min_tpy: float) -> float:
    if stats["trades"] < 10 or not ys:
        return -5.0
    y = np.clip(np.array(ys), -3, 3)
    score = float(y.mean() - 0.5 * y.std())
    tpy = stats["trades_per_year"]
    if tpy < min_tpy:
        score -= 2.0 * (min_tpy - tpy) / min_tpy
    if stats["max_dd"] < -0.30:
        score -= (abs(stats["max_dd"]) - 0.30) * 5
    return round(score, 4)


class Ledger:
    def __init__(self):
        self.rows: list[dict] = []
        self.returns: dict[str, np.ndarray] = {}
        self.by_key: dict[str, dict] = {}

    def __len__(self):
        return len(self.rows)

    def add(self, row: dict, dr: pd.Series):
        self.rows.append(row)
        self.by_key[row["key"]] = row
        self.returns[row["key"]] = dr.to_numpy()
        self.index = dr.index

    def sr_variance(self) -> float:
        """Variance of per-period (daily) Sharpe across all trials (for DSR)."""
        srs = []
        for r in self.returns.values():
            sd = r.std(ddof=1)
            srs.append(r.mean() / sd if sd > 0 else 0.0)
        return float(np.var(srs, ddof=1)) if len(srs) > 1 else 0.0

    def effective_trials(self, max_cols: int = 1500, corr_cut: float = 0.5, seed: int = 0) -> dict:
        """López de Prado (2019): cluster correlated trials; N_eff = number of clusters and the
        Sharpe variance is measured across cluster-average return streams. Evolutionary search
        produces many near-copies, so raw N would overstate the number of independent ideas."""
        from scipy.cluster.hierarchy import fcluster, linkage
        from scipy.spatial.distance import squareform

        keys = [k for k, r in self.returns.items() if r.std() > 0]
        if len(keys) > max_cols:
            rng = np.random.default_rng(seed)
            keys = list(rng.choice(keys, max_cols, replace=False))
        X = np.column_stack([self.returns[k] for k in keys])
        C = np.nan_to_num(np.corrcoef(X, rowvar=False))
        D = np.sqrt(np.clip(0.5 * (1 - C), 0, None))
        np.fill_diagonal(D, 0)
        Z = linkage(squareform(D, checks=False), method="average")
        labels = fcluster(Z, t=np.sqrt(0.5 * (1 - corr_cut)), criterion="distance")
        srs = []
        for c in np.unique(labels):
            r = X[:, labels == c].mean(axis=1)
            sd = r.std(ddof=1)
            srs.append(r.mean() / sd if sd > 0 else 0.0)
        k = len(srs)
        frac = len(keys) / max(len(self.returns), 1)
        return {"n_eff": max(int(round(k / frac)) if frac < 1 else k, 1), "n_raw": len(self.returns),
                "sr_var": float(np.var(srs, ddof=1)) if k > 1 else 0.0, "clusters_in_sample": k}

    def matrix(self, max_cols: int = 1500, seed: int = 0) -> np.ndarray:
        keys = list(self.returns)
        if len(keys) > max_cols:
            rng = np.random.default_rng(seed)
            keys = list(rng.choice(keys, max_cols, replace=False))
        return np.column_stack([self.returns[k] for k in keys])

    def leaderboard(self, n=15) -> list[dict]:
        rows = sorted(self.rows, key=lambda r: r["score"], reverse=True)
        return rows[:n]

    def family_stats(self) -> dict:
        df = pd.DataFrame(self.rows)
        if df.empty:
            return {}
        g = df.groupby("family")["score"]
        return {f: {"trials": int(g.count()[f]), "best": round(float(g.max()[f]), 3),
                    "median": round(float(g.median()[f]), 3)} for f in g.count().index}

    def save(self, path: Path):
        pd.DataFrame(self.rows).to_csv(path, index=False)


def evaluate_trial(lab, p: dict, gen: int, source: str, ledger: Ledger, min_tpy: float) -> dict:
    p = clean(p)
    k = S.key(p)
    if k in ledger.by_key:
        return ledger.by_key[k]
    stats, trades, dr = lab.evaluate(p, "research")
    a, _ = lab.win["research"]
    ys = MX.yearly_sharpes(trades, a, lab.window_end("research"), lab.risk)
    row = {
        "trial": len(ledger) + 1, "gen": gen, "source": source, "key": k,
        "family": p["family"], "tf": p["tf"], "desc": S.describe(p["family"], p),
        "params": json.dumps(p), "score": robustness_score(stats, ys, min_tpy),
        "years_positive": int(sum(1 for y in ys if y > 0)), "years": len(ys),
        **{f"is_{m}": round(v, 4) if isinstance(v, float) and math.isfinite(v) else v for m, v in stats.items()},
    }
    ledger.add(row, dr)
    return row


def run(lab, cfg: dict, log=print) -> tuple[Ledger, list[dict]]:
    sc = cfg["search"]
    rng = np.random.default_rng(sc["seed"])
    fams = list(S.SPACES)
    pop_n, n_elite = sc["population"], max(2, int(sc["population"] * sc["elite_frac"]))
    min_tpy = sc["min_trades_per_year"]
    ledger = Ledger()
    history = []
    agent_log = []

    population = [dict(S.sample(fams[i % len(fams)], rng), _source="random") for i in range(pop_n)]
    for g in range(sc["generations"]):
        t0 = time.time()
        rows = [evaluate_trial(lab, p, g, p.get("_source", "?"), ledger, min_tpy) for p in population]
        # hypotheses from the agent, if any, are attached to the rows for the report
        for p in population:
            if "_hypothesis" in p:
                ledger.by_key[S.key(clean(p))]["hypothesis"] = p["_hypothesis"]

        lb = ledger.leaderboard(len(ledger))
        scores = np.array([r["score"] for r in rows])
        history.append({
            "gen": g, "trials_total": len(ledger),
            "best_score_ever": lb[0]["score"],
            "gen_best": float(scores.max()), "gen_median": float(np.median(scores)),
            "gen_p75": float(np.percentile(scores, 75)),
            "best_desc": lb[0]["desc"], "secs": round(time.time() - t0, 1),
        })
        log(f"gen {g:2d} | trials {len(ledger):5d} | gen median {np.median(scores):+.3f} "
            f"| gen best {scores.max():+.3f} | best ever {lb[0]['score']:+.3f} {lb[0]['desc']}")

        # ---- IMPROVE: build next generation -------------------------------------------------
        elites = [json.loads(r["params"]) for r in lb[:n_elite]]
        nxt = [dict(e, _source="elite") for e in elites]
        n_imm = int(pop_n * 0.15)
        n_llm = 0
        if sc.get("use_llm_agent"):
            board = [{"desc": r["desc"], "params": json.loads(r["params"]), "score": r["score"],
                      "trades_per_year": r["is_trades_per_year"], "max_dd": r["is_max_dd"],
                      "years_positive": f"{r['years_positive']}/{r['years']}"} for r in lb[:15]]
            props, raw = agent_llm.propose(board, ledger.family_stats(), sc["llm_proposals_per_gen"], sc["llm_model"])
            agent_log.append({"gen": g, "n_valid": len(props), "note": raw[:300] if not props else "ok"})
            for p in props:
                p["_source"] = "llm"
            nxt += props
            n_llm = len(props)
            if not props:
                log(f"         agent: no proposals ({raw[:120]})")
        while len(nxt) < pop_n - n_imm:
            a = elites[rng.integers(len(elites))]
            if rng.random() < 0.3:
                b = elites[rng.integers(len(elites))]
                child = S.mutate(S.crossover(a, b, rng), rng, sc["mutation_rate"] * 0.5)
            else:
                child = S.mutate(a, rng, sc["mutation_rate"])
            child["_source"] = "evolve"
            nxt.append(child)
        while len(nxt) < pop_n:
            nxt.append(dict(S.sample(fams[rng.integers(len(fams))], rng), _source="random"))
        population = nxt
        history[-1]["llm_proposals"] = n_llm

    ledger.agent_log = agent_log
    return ledger, history
