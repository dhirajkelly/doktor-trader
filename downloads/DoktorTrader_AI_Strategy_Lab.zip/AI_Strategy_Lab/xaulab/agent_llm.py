"""Optional LLM research agent (Claude via the Anthropic API).

The agent plays "quant researcher": it reads the IN-SAMPLE leaderboard only and proposes new
parameter sets inside the fixed strategy spaces, each with a one-line hypothesis.

Guardrails:
  * It never sees validation or holdout results (the loop simply does not pass them).
  * Proposals are coerced/validated against the parameter spaces; anything invalid is dropped.
  * Every proposal is logged in the trial ledger and counts toward N in the Deflated Sharpe Ratio,
    so asking the AI for more ideas makes the statistical bar HIGHER, not lower.

Needs:  pip install anthropic   and   env ANTHROPIC_API_KEY
"""
from __future__ import annotations

import json
import os
import re

from . import strategies as S

SYSTEM = """You are a disciplined quantitative researcher working on XAUUSD (spot gold) strategies.
You propose new parameter sets for EXISTING strategy families only. You cannot write code.
Your goal is robustness, not the highest backtest number: prefer ideas with a clear market rationale
(trend persistence, session volatility, mean reversion after stretched moves), sensible trade counts,
and parameters away from the edges of their ranges. Avoid near-duplicates of the leaderboard.
Reply with JSON only."""


def _spaces_doc() -> str:
    lines = []
    for fam, sp in S.SPACES.items():
        parts = []
        for k, spec in sp.items():
            if spec[0] == "choice":
                parts.append(f"{k}: one of {spec[1]}")
            else:
                parts.append(f"{k}: {spec[0]} {spec[1]}..{spec[2]} step {spec[3]}")
        lines.append(f"- {fam}: " + "; ".join(parts))
    return "\n".join(lines)


def build_prompt(leaderboard: list[dict], family_stats: dict, n: int) -> str:
    return f"""Strategy families and their parameter spaces:
{_spaces_doc()}

Notes: ema_trend requires slow >= 1.5*fast. session_break uses the Asian range 00:00..range_end_h UTC.
atr_sl = stop distance in ATR(14) multiples, rr = take-profit as a multiple of the stop, max_hold in bars.

In-sample leaderboard (research window only; score = mean yearly Sharpe - 0.5*std, penalised for
too few trades and deep drawdowns):
{json.dumps(leaderboard, indent=1)}

Per-family summary of all trials so far:
{json.dumps(family_stats, indent=1)}

Propose {n} NEW parameter sets. Mix: some refinements around robust leaders, some genuinely
different hypotheses in under-explored families/timeframes. Return exactly:
{{"proposals": [{{"family": "...", "tf": "...", <every parameter of that family>, "hypothesis": "<one line>"}}]}}"""


def propose(leaderboard: list[dict], family_stats: dict, n: int, model: str, client=None) -> tuple[list[dict], str]:
    """Returns (valid_param_dicts, raw_text). Never raises: on any failure returns ([], reason)."""
    try:
        if client is None:
            import anthropic  # noqa: WPS433

            if not os.environ.get("ANTHROPIC_API_KEY"):
                return [], "ANTHROPIC_API_KEY not set"
            client = anthropic.Anthropic()
        msg = client.messages.create(
            model=model,
            max_tokens=4000,
            system=SYSTEM,
            messages=[{"role": "user", "content": build_prompt(leaderboard, family_stats, n)}],
        )
        text = "".join(getattr(b, "text", "") for b in msg.content)
    except Exception as e:  # network, auth, model name...
        return [], f"agent error: {e!r}"

    m = re.search(r"\{.*\}", text, re.S)
    if not m:
        return [], "no JSON in reply"
    try:
        obj = json.loads(m.group(0))
    except json.JSONDecodeError:
        return [], "invalid JSON"
    out = []
    for raw in obj.get("proposals", [])[: n * 2]:
        hyp = str(raw.get("hypothesis", ""))[:200]
        p = S.validate(raw)
        if p is not None:
            p["_hypothesis"] = hyp
            out.append(p)
    return out[:n], text
