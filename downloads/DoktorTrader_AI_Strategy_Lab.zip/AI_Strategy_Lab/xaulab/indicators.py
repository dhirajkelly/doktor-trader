"""Fast indicators (numba). All are causal: value at i uses data up to and including bar i."""
from __future__ import annotations

import numpy as np
from numba import njit


@njit(cache=True)
def ema(x, n):
    out = np.empty_like(x)
    a = 2.0 / (n + 1.0)
    out[0] = x[0]
    for i in range(1, len(x)):
        out[i] = a * x[i] + (1 - a) * out[i - 1]
    # warm-up: mark first n bars as nan
    for i in range(min(n, len(x))):
        out[i] = np.nan
    return out


@njit(cache=True)
def atr(high, low, close, n):
    m = len(close)
    tr = np.empty(m)
    tr[0] = high[0] - low[0]
    for i in range(1, m):
        tr[i] = max(high[i] - low[i], abs(high[i] - close[i - 1]), abs(low[i] - close[i - 1]))
    out = np.full(m, np.nan)
    if m <= n:
        return out
    s = 0.0
    for i in range(n):
        s += tr[i]
    out[n - 1] = s / n
    for i in range(n, m):
        out[i] = (out[i - 1] * (n - 1) + tr[i]) / n
    return out


@njit(cache=True)
def rsi(close, n):
    m = len(close)
    out = np.full(m, np.nan)
    if m <= n:
        return out
    g = 0.0
    l = 0.0
    for i in range(1, n + 1):
        d = close[i] - close[i - 1]
        if d > 0:
            g += d
        else:
            l -= d
    g /= n
    l /= n
    out[n] = 100.0 if l == 0 else 100.0 - 100.0 / (1.0 + g / l)
    for i in range(n + 1, m):
        d = close[i] - close[i - 1]
        up = d if d > 0 else 0.0
        dn = -d if d < 0 else 0.0
        g = (g * (n - 1) + up) / n
        l = (l * (n - 1) + dn) / n
        out[i] = 100.0 if l == 0 else 100.0 - 100.0 / (1.0 + g / l)
    return out


@njit(cache=True)
def adx(high, low, close, n):
    m = len(close)
    out = np.full(m, np.nan)
    if m <= 2 * n + 1:
        return out
    tr_s = 0.0
    pdm_s = 0.0
    ndm_s = 0.0
    dx = np.full(m, np.nan)
    for i in range(1, m):
        up = high[i] - high[i - 1]
        dn = low[i - 1] - low[i]
        pdm = up if (up > dn and up > 0) else 0.0
        ndm = dn if (dn > up and dn > 0) else 0.0
        tr = max(high[i] - low[i], abs(high[i] - close[i - 1]), abs(low[i] - close[i - 1]))
        if i <= n:
            tr_s += tr
            pdm_s += pdm
            ndm_s += ndm
        else:
            tr_s = tr_s - tr_s / n + tr
            pdm_s = pdm_s - pdm_s / n + pdm
            ndm_s = ndm_s - ndm_s / n + ndm
        if i >= n and tr_s > 0:
            pdi = 100 * pdm_s / tr_s
            ndi = 100 * ndm_s / tr_s
            s = pdi + ndi
            dx[i] = 0.0 if s == 0 else 100 * abs(pdi - ndi) / s
    # smooth dx
    s = 0.0
    for i in range(n, 2 * n):
        s += dx[i]
    out[2 * n - 1] = s / n
    for i in range(2 * n, m):
        out[i] = (out[i - 1] * (n - 1) + dx[i]) / n
    return out


@njit(cache=True)
def rolling_max_prev(x, n):
    """Highest value of the PREVIOUS n bars (excludes bar i)."""
    m = len(x)
    out = np.full(m, np.nan)
    for i in range(n, m):
        v = x[i - n]
        for j in range(i - n + 1, i):
            if x[j] > v:
                v = x[j]
        out[i] = v
    return out


@njit(cache=True)
def rolling_min_prev(x, n):
    m = len(x)
    out = np.full(m, np.nan)
    for i in range(n, m):
        v = x[i - n]
        for j in range(i - n + 1, i):
            if x[j] < v:
                v = x[j]
        out[i] = v
    return out
