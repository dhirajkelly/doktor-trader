"""Performance metrics + overfitting statistics (DSR, PBO)."""
from __future__ import annotations

import math

import numpy as np
import pandas as pd
from scipy import stats

EULER_GAMMA = 0.5772156649015329


def daily_returns(trades: pd.DataFrame, start, end, risk: float) -> pd.Series:
    """Fixed-fractional daily returns: each trade contributes risk * R on its exit day."""
    days = pd.bdate_range(pd.Timestamp(start).tz_localize(None).normalize(),
                          pd.Timestamp(end).tz_localize(None).normalize())
    s = pd.Series(0.0, index=days)
    if len(trades):
        d = trades["exit_time"].dt.tz_localize(None).dt.normalize()
        r = (risk * trades["R"]).groupby(d).sum()
        r = r[r.index.isin(days)]
        s.loc[r.index] = r.values
    return s


def summarize(trades: pd.DataFrame, start, end, risk: float = 0.01) -> dict:
    years = max((pd.Timestamp(end) - pd.Timestamp(start)).days / 365.25, 1e-9)
    n = len(trades)
    out = {"trades": n, "trades_per_year": n / years}
    if n == 0:
        out.update(sharpe=0.0, pf=0.0, expectancy_R=0.0, win_rate=0.0, max_dd=0.0, cagr=0.0,
                   total_R=0.0, avg_win_R=0.0, avg_loss_R=0.0, long_share=0.0, calmar=0.0)
        return out
    R = trades["R"].to_numpy()
    wins, losses = R[R > 0], R[R <= 0]
    dr = daily_returns(trades, start, end, risk)
    eq = (1 + dr).cumprod()
    dd = (eq / eq.cummax() - 1).min()
    sd = dr.std(ddof=1)
    sharpe = float(dr.mean() / sd * math.sqrt(252)) if sd > 0 else 0.0
    cagr = float(eq.iloc[-1] ** (1 / years) - 1) if eq.iloc[-1] > 0 else -1.0
    out.update(
        sharpe=sharpe,
        pf=float(wins.sum() / -losses.sum()) if losses.sum() < 0 else float("inf"),
        expectancy_R=float(R.mean()),
        win_rate=float((R > 0).mean()),
        max_dd=float(dd),
        cagr=cagr,
        calmar=float(cagr / -dd) if dd < 0 else 0.0,
        total_R=float(R.sum()),
        avg_win_R=float(wins.mean()) if len(wins) else 0.0,
        avg_loss_R=float(losses.mean()) if len(losses) else 0.0,
        long_share=float((trades["dir"] > 0).mean()),
    )
    return out


def yearly_sharpes(trades: pd.DataFrame, start, end, risk=0.01) -> list[float]:
    out = []
    for y in range(pd.Timestamp(start).year, pd.Timestamp(end).year + 1):
        a = max(pd.Timestamp(start), pd.Timestamp(f"{y}-01-01"))
        b = min(pd.Timestamp(end), pd.Timestamp(f"{y}-12-31"))
        if (b - a).days < 120:
            continue
        t = trades[(trades["exit_time"].dt.tz_localize(None) >= a) & (trades["exit_time"].dt.tz_localize(None) <= b)]
        dr = daily_returns(t, a, b, risk)
        sd = dr.std(ddof=1)
        out.append(float(dr.mean() / sd * math.sqrt(252)) if sd > 0 else 0.0)
    return out


# ----------------------------------------------------------------------------------------------
# Deflated Sharpe Ratio (Bailey & López de Prado, 2014)
# ----------------------------------------------------------------------------------------------
def expected_max_sharpe(n_trials: int, var_sr: float) -> float:
    """Expected maximum of N per-period Sharpe estimates under the null (true SR = 0)."""
    if n_trials < 2 or var_sr <= 0:
        return 0.0
    z1 = stats.norm.ppf(1 - 1.0 / n_trials)
    z2 = stats.norm.ppf(1 - 1.0 / (n_trials * math.e))
    return math.sqrt(var_sr) * ((1 - EULER_GAMMA) * z1 + EULER_GAMMA * z2)


def deflated_sharpe(returns: np.ndarray, n_trials: int, trial_sr_var: float) -> dict:
    """returns: per-period (daily) returns of the selected strategy.
    trial_sr_var: variance of the per-period Sharpe across ALL trials tried (from the ledger)."""
    r = np.asarray(returns, float)
    T = len(r)
    sd = r.std(ddof=1)
    if T < 30 or sd == 0:
        return {"dsr": 0.0, "sr": 0.0, "sr0": 0.0}
    sr = r.mean() / sd
    sk = stats.skew(r)
    ku = stats.kurtosis(r, fisher=False)
    sr0 = expected_max_sharpe(n_trials, trial_sr_var)
    denom = math.sqrt(max(1 - sk * sr + (ku - 1) / 4 * sr * sr, 1e-12))
    z = (sr - sr0) * math.sqrt(T - 1) / denom
    return {"dsr": float(stats.norm.cdf(z)), "sr": float(sr), "sr0": float(sr0),
            "sr_ann": float(sr * math.sqrt(252)), "sr0_ann": float(sr0 * math.sqrt(252)),
            "skew": float(sk), "kurt": float(ku), "T": T, "N": n_trials}


# ----------------------------------------------------------------------------------------------
# Probability of Backtest Overfitting via CSCV (Bailey, Borwein, López de Prado, Zhu 2015)
# ----------------------------------------------------------------------------------------------
def pbo_cscv(M: np.ndarray, S: int = 16, max_combos: int = 4000, seed: int = 0) -> dict:
    """M: T x N matrix of per-period returns (rows = time, cols = trials).
    Splits time into S blocks; for every combination of S/2 blocks as in-sample, picks the best
    trial IS and records its OOS rank. PBO = share of splits where the IS-winner is below the OOS median."""
    from itertools import combinations

    T, N = M.shape
    if N < 4 or T < S * 10:
        return {"pbo": float("nan"), "n_splits": 0}
    blocks = np.array_split(np.arange(T), S)
    combos = list(combinations(range(S), S // 2))
    rng = np.random.default_rng(seed)
    if len(combos) > max_combos:
        combos = [combos[i] for i in rng.choice(len(combos), max_combos, replace=False)]

    def sharpe_cols(X):
        sd = X.std(axis=0, ddof=1)
        sd[sd == 0] = np.inf
        return X.mean(axis=0) / sd

    logits = []
    deg = 0
    for c in combos:
        is_idx = np.concatenate([blocks[k] for k in c])
        oos_idx = np.concatenate([blocks[k] for k in range(S) if k not in c])
        sr_is = sharpe_cols(M[is_idx])
        sr_oos = sharpe_cols(M[oos_idx])
        best = int(np.argmax(sr_is))
        rank = stats.rankdata(sr_oos)[best] / (N + 1)  # relative rank in (0,1)
        logits.append(math.log(rank / (1 - rank)))
        if sr_oos[best] <= 0:
            deg += 1
    logits = np.array(logits)
    return {"pbo": float((logits <= 0).mean()), "n_splits": len(combos),
            "p_oos_loss": deg / len(combos), "logit_median": float(np.median(logits))}


def monte_carlo_dd(R: np.ndarray, risk: float, runs: int = 2000, seed: int = 0) -> dict:
    """Bootstrap trade order to get the distribution of max drawdown & losing streaks."""
    rng = np.random.default_rng(seed)
    R = np.asarray(R, float)
    if len(R) < 5:
        return {"dd_p50": 0.0, "dd_p95": 0.0, "streak_p95": 0}
    dds, streaks = [], []
    for _ in range(runs):
        s = rng.choice(R, size=len(R), replace=True)
        eq = np.cumprod(1 + risk * s)
        dds.append((eq / np.maximum.accumulate(eq) - 1).min())
        loss = s <= 0
        best = cur = 0
        for x in loss:
            cur = cur + 1 if x else 0
            best = max(best, cur)
        streaks.append(best)
    dds = np.array(dds)
    return {"dd_p50": float(np.percentile(dds, 50)), "dd_p95": float(np.percentile(dds, 5)),
            "streak_p50": int(np.percentile(streaks, 50)), "streak_p95": int(np.percentile(streaks, 95))}
