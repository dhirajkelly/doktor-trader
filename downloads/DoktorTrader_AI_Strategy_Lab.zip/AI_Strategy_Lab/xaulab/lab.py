"""Evaluation core: turns a parameter dict into trades on a given window, with zero look-ahead.

For a window [start, end] the bars are TRUNCATED at `end` before indicators are computed, so
nothing after `end` can influence a result. Signals before `start` are zeroed (indicators may use
earlier history for warm-up, which is fine and causal).
"""
from __future__ import annotations

import hashlib
import json
import tomllib
from pathlib import Path

import numpy as np
import pandas as pd

from . import data as D
from . import metrics as MX
from .engine import CostModel, backtest
from .strategies import GENERATORS, Cache


def load_config(path="config.toml") -> dict:
    with open(path, "rb") as f:
        return tomllib.load(f)


def config_hash(cfg: dict) -> str:
    keep = {k: cfg[k] for k in ("data", "split", "costs")}
    return hashlib.sha256(json.dumps(keep, sort_keys=True, default=str).encode()).hexdigest()[:12]


class Lab:
    WINDOWS = ("research", "validation", "holdout")

    def __init__(self, cfg: dict, root: str | Path = "."):
        self.cfg = cfg
        self.root = Path(root)
        dc, cc = cfg["data"], cfg["costs"]
        frames = D.build_timeframes(self.root / dc["m1_path"], dc["timeframes"], self.root / "data")
        self.point = dc["point"]
        self.full = {tf: D.to_bars(df, tf, self.point, cc["spread_floor_points"], cc["spread_mult"])
                     for tf, df in frames.items()}
        self.raw_spread_pts = {tf: df["spread"].to_numpy(float) for tf, df in frames.items()}
        self.cost = CostModel.from_cfg(cc, self.point)
        sp = cfg["split"]
        self.win = {
            "research": (sp["research_start"], sp["research_end"]),
            "validation": (sp["validation_start"], sp["validation_end"]),
            "holdout": (sp["holdout_start"], sp["holdout_end"]),
        }
        self._trunc: dict = {}
        self._holdout_unlocked = False
        self.risk = cfg["risk"]["risk_per_trade"]

    # -------------------------------------------------------------------------------------------
    def unlock_holdout(self):
        self._holdout_unlocked = True

    def _bars_until(self, tf: str, window: str):
        if window == "holdout" and not self._holdout_unlocked:
            raise PermissionError("Holdout is locked. Only the final gate may open it (Lab.unlock_holdout).")
        k = (tf, window)
        if k not in self._trunc:
            b = self.full[tf]
            end = pd.Timestamp(self.win[window][1], tz="UTC") + pd.Timedelta(days=1)
            n = int(np.searchsorted(b.index.values, end.to_datetime64()))
            sub = D.Bars(tf, b.index[:n], b.open[:n], b.high[:n], b.low[:n], b.close[:n],
                         b.spread_px[:n], b.day_id[:n], b.weekday[:n], b.hour[:n])
            start = pd.Timestamp(self.win[window][0], tz="UTC")
            s_idx = int(np.searchsorted(sub.index.values, start.to_datetime64()))
            self._trunc[k] = (sub, Cache(sub), s_idx, n)
        return self._trunc[k]

    def trades(self, p: dict, window: str, spread_mult: float = 1.0, slip_mult: float = 1.0) -> pd.DataFrame:
        bars, cache, s_idx, n = self._bars_until(p["tf"], window)
        sig, sl = GENERATORS[p["family"]](cache, p)
        sig = sig.copy()
        sig[:s_idx] = 0
        cost = self.cost
        sp = None
        if spread_mult != 1.0 or slip_mult != 1.0:
            cc = self.cfg["costs"]
            cost = CostModel.from_cfg(cc, self.point, slip_mult=slip_mult)
            raw = self.raw_spread_pts[p["tf"]][:n]
            sp = np.maximum(raw * cc["spread_mult"] * spread_mult, cc["spread_floor_points"] * spread_mult) * self.point
        return backtest(bars, sig, sl, p["rr"], p["max_hold"], cost, spread_override=sp)

    def evaluate(self, p: dict, window: str, **kw) -> tuple[dict, pd.DataFrame, pd.Series]:
        t = self.trades(p, window, **kw)
        a, b = self.win[window]
        end = min(pd.Timestamp(b), self.full[p["tf"]].index[-1].tz_localize(None))
        stats = MX.summarize(t, a, end, self.risk)
        dr = MX.daily_returns(t, a, end, self.risk)
        return stats, t, dr

    def window_end(self, window: str) -> pd.Timestamp:
        b = pd.Timestamp(self.win[window][1])
        last = max(x.index[-1] for x in self.full.values()).tz_localize(None)
        return min(b, last)
